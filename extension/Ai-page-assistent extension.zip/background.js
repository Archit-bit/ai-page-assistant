// background.js

// This file is required for some extension capabilities in Manifest V3.
// For our simple MVP, we don't need persistent background state.
// We keep it as a placeholder to ensure the extension loads correctly
// and for future extensibility (e.g., handling cross-origin requests if needed, 
// though host_permissions mostly covers fetch from popup in v3).

console.log("AI Page Assistant background script loaded.");
