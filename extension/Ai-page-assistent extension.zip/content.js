// content.js

// Listens for messages from the popup
browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getPageContext") {
    // Extract page details
    const context = {
      title: document.title,
      url: window.location.href,
      selection: window.getSelection().toString().trim(),
      // Extract the visible text of the body. 
      // This is a naive but effective way for an MVP.
      pageText: document.body ? document.body.innerText.trim() : ""
    };

    // Return the context object directly as the response
    return Promise.resolve(context);
  }
});

console.log("AI Page Assistant content script loaded.");
